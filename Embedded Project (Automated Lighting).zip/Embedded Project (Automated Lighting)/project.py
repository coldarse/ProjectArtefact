
from tkinter import *
from gpiozero import OutputDevice
import RPi.GPIO 
import tkinter.font

RPi.GPIO.setmode(RPi.GPIO.BCM)
switch = OutputDevice(26,active_high = 1, initial_value = 0)



win = Tk()
win.title("Smart Home")

myFont = tkinter.font.Font(family = 'Arial', size = 12, weight = "bold")

def led1Toggle():
    if switch.is_active:
        switch.toggle()
        ledButton1["text"] = "Turn on Automatic Lighting for Room 1"
    else:
        switch.toggle()
        ledButton1["text"] = "Turn off Automatic Lighting for Room 1"

ledButton1 = Button(win, text = 'Turn on Automatic Lighting for Room 1', font = myFont, command = led1Toggle, bg = 'yellow', height = 1, width = 40)
ledButton1.grid(row = 0, column = 1)

def exit():
    RPi.GPIO.cleanup()
    win.destroy()

exitBut = Button(win, text = 'Exit', font = myFont, command = exit, bg = 'red', height = 1, width = 10)
exitBut.grid(row = 3, column = 1)

win.protocol("WM_DELETE_WINDOW", exit)

win.mainloop()
    






    
