#include "mbed.h"
#include "ultrasonic.h"
 
PwmOut led(p22);
DigitalOut led1(LED1);
AnalogIn switches(p17);

void dist(int distance)
{
    printf("Distance changed to %dmm\r\n", distance);
    if(distance > 1000)
    {
       wait(5);
       led = 0;
       led1 = 0;
    }
    else
    {
       led = 1;
       led1 = 1;
    }
    
 
}

ultrasonic sensor(p25,p7,0.1,1, &dist);

int main() 
{
   while(1)
   {
        if(switches == 1)
        {
            sensor.startUpdates();
            while(switches == 1)
            {
                sensor.checkDistance(); 
            }
        }
        else
        {
            led = 0;
            led1 = 0;
        }
    }
}

